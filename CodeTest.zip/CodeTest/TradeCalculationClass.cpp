#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
using namespace std;

#include "TradeClass.h"
#include "TradeCalculationClass.h"
#include "constants.h"

TradeCalculationClass::TradeCalculationClass()
{
    lastTimestamp = 0;
    curMaxTimeGap = 0;
    curTotalVolume = 0;
    curTotalVolumePrice = 0;
    curMaxPrice = 0;
}

TradeCalculationClass::TradeCalculationClass(TradeClass &tradeData)
{
    symbol = tradeData.getSymbol();
    lastTimestamp = tradeData.getTimestamp();
    curMaxTimeGap = 0;
    curTotalVolume = tradeData.getVolume();
    curTotalVolumePrice = tradeData.getVolume() * tradeData.getPrice();
    curMaxPrice = tradeData.getPrice();
}

void TradeCalculationClass::readTradeData(TradeClass &tradeData)
{
    lastTimestamp = tradeData.getTimestamp();
    curMaxTimeGap = 0;
    curTotalVolume = tradeData.getVolume();
    curTotalVolumePrice = tradeData.getVolume() * tradeData.getPrice();
    curMaxPrice = tradeData.getPrice();
}

void TradeCalculationClass::updateTrade(TradeClass &tradeData)
{
    int curTime = tradeData.getTimestamp();
    int curPrice = tradeData.getPrice();
    int curVolume = tradeData.getVolume();

    int curTimeGap = curTime - lastTimestamp;
    if  (curTimeGap > curMaxTimeGap)
    {
        curMaxTimeGap = curTimeGap;
    }
    lastTimestamp = curTime;
    curTotalVolume += curVolume;
    curTotalVolumePrice += curVolume * curPrice;
    
    if (curPrice > curMaxPrice)
    {
        curMaxPrice = curPrice;
    }
}

string TradeCalculationClass::getSymbol()
{
    return symbol;
}

int TradeCalculationClass::getLastTime()
{
    return lastTimestamp;
}

int TradeCalculationClass::getCurTimeGap()
{
    return curMaxTimeGap;
}

int TradeCalculationClass::getCurVol()
{
    return curTotalVolume;
}

int TradeCalculationClass::getCurVolPrice()
{
    return curTotalVolumePrice;
}

int TradeCalculationClass::getCurMaxPrice()
{
    return curMaxPrice;
}

void TradeCalculationClass::toFile(ofstream &outFile)
{
    outFile << symbol << ',' << curMaxTimeGap << ',' << curTotalVolume << ',';
	outFile << curTotalVolumePrice/curTotalVolume << ',' << curMaxPrice << endl;
}
