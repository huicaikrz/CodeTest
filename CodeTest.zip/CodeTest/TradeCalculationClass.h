#ifndef _TRADECALCULATIONCLASS_H_
#define _TRADECALCULATIONCLASS_H_

#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <sstream>
using namespace std;

#include "TradeClass.h"

//读取并记录某个资产的累计交易信息
class TradeCalculationClass
{
    private:
        string symbol;
        int lastTimestamp;
        int curMaxTimeGap;
        int curTotalVolume;
        int curTotalVolumePrice;
        int curMaxPrice;
    public:
        TradeCalculationClass();
        TradeCalculationClass(TradeClass &tradeData);
        
        void readTradeData(TradeClass &tradeData);
        void updateTrade(TradeClass &tradeData);

        string getSymbol();
        int getLastTime();
        int getCurTimeGap();
        int getCurVol();
        int getCurVolPrice();
        int getCurMaxPrice();
        
        void toFile(ofstream &outFile);
};

#endif