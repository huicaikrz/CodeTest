#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include<stdlib.h>
using namespace std;

#include "TradeClass.h"
#include "constants.h"

TradeClass::TradeClass()
{
    timestamp = 0;
    volume = 0;
    price = 0;
}

void TradeClass::readTrade(ifstream &inFile)
{
    string lineStr;
    string str;
    
    getline(inFile, lineStr);
    stringstream ss(lineStr);
    int pos = 0;
    string trade[INPUT_LENGTH];
    while (getline(ss, str, ','))
    {
        trade[pos] = str;
        pos++;
    }
    
    timestamp = atoi(trade[INPUT_TIMESTAMP].c_str());
    symbol = trade[INPUT_SYMBOL];
    volume = atoi(trade[INPUT_VOLUME].c_str());
    price = atoi(trade[INPUT_PRICE].c_str());
}

int TradeClass::getTimestamp()
{
    return timestamp;
}

int TradeClass::getPrice()
{
    return price;
}

int TradeClass::getVolume()
{
    return volume;
}

string TradeClass::getSymbol()
{
    return symbol;    
}