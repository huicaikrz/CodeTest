#ifndef _TRADECLASS_H_
#define _TRADECLASS_H_

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include<stdlib.h>
using namespace std;

//读取并记录某条trade的信息
class TradeClass
{
    private:
        int timestamp;
        int volume;
        int price;
        string symbol;
    public:
        TradeClass();
        void readTrade(ifstream &inFile);
        int getTimestamp();
        int getVolume();
        int getPrice();
        string getSymbol();
};

#endif