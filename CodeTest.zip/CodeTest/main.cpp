#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <sstream>
using namespace std;

#include "constants.h"
#include "TradeClass.h"
#include "TradeCalculationClass.h"

int main()
{
    ifstream inFile;
    string inFileName;
    inFileName = "input.csv";
    
    inFile.open(inFileName.c_str());
    
    
    TradeClass tradeData;
    
    TradeCalculationClass *tradeDetail;
    
    //包含了symbol与tradeDetail地址的键值对
    std::map <string, TradeCalculationClass *> mapSymbol;
    map<string, TradeCalculationClass *>::iterator iter;
    
    while (!inFile.eof())
    {
        tradeData.readTrade(inFile);
    
        //读取交易数据
        iter = mapSymbol.find(tradeData.getSymbol());
        if (iter == mapSymbol.end())
        {
            //如果这个security之前不在表里
            tradeDetail = new TradeCalculationClass(tradeData);
		    mapSymbol.insert( std :: pair < string , TradeCalculationClass *> 
		                        (tradeData.getSymbol(), tradeDetail)); 
        }
        else
        {
            //这个security已经在表中, 则用新的信息更新tradeDetail
            TradeCalculationClass *temp;
    	    temp = iter->second;
    	    
    	    temp->updateTrade(tradeData);
        }
    }
    inFile.close();
    
    //输出到文件中
    ofstream outFile;
    string outFileName; 
    outFileName = "output.csv";
    outFile.open(outFileName.c_str());
    
    for (iter = mapSymbol.begin(); iter != mapSymbol.end(); iter++) 
	{
        string symbol = iter->first;
    	TradeCalculationClass *temp = iter->second;
    	temp->toFile(outFile);
    }
    outFile.close();
}