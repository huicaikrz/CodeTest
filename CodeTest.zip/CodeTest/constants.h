#ifndef _CONSTANTS_H_
#define _CONSTANTS_H_

#include <iostream>
#include <string>
using namespace std;

//一些常数, 用于记录输入信息每个元素的位置
const int INPUT_LENGTH = 4;
const int INPUT_TIMESTAMP = 0;
const int INPUT_SYMBOL = 1;
const int INPUT_VOLUME = 2;
const int INPUT_PRICE = 3;

#endif